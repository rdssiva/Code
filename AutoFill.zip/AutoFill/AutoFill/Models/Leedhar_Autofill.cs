﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.Entity;
namespace AutoFill.Models
{
    public class Leedhar_Autofill:DbContext
    {

        public DbSet<Country> Country { get; set; }
    }
}