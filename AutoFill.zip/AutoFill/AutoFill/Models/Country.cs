﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ComponentModel.DataAnnotations;
namespace AutoFill.Models
{
   public class Country
    {

        [Key]
        public virtual int CountryCode { get; set; }
        public virtual int CountryNumber { get; set; }
        [Required]
        public virtual String CountryName { get; set; }
      
    }
}
