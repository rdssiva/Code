﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using AutoFill.Models;
using System.IO;
namespace AutoFill.Controllers
{
    public class HomeController : Controller
    {

        Leedhar_Autofill _DB = new Leedhar_Autofill();
        public ActionResult Index()
        {
            ViewBag.Message = "Welcome to ASP.NET MVC!";

            return View();
        }

     

        public ActionResult JsonCountry()
        {
            var result = _DB.Country
                    .Select(x => new { x.CountryName, x.CountryCode });
            return Json(result, JsonRequestBehavior.AllowGet);
        }

        #region Country
        [HttpGet]
        public ActionResult Country(int id = 0)
        {
            return View();
        }

        [HttpPost]
        public ActionResult Country()
        {

            int page = int.Parse(Request.Form["page"]);
            int rp = int.Parse(Request.Form["rp"]);
            string qtype = Request.Form["qtype"].ToString();
            string query = Request.Form["query"].ToString();
            string sortname = Request.Form["sortname"].ToString();
            string sortorder = Request.Form["sortorder"].ToString();


            switch (Request.Form["fntype"])
            {
                case "Add":
                    if (Request.Form["CountryNumber"] != "" && Request.Form["CountryNumber"] != null)
                    {
                        int CountryNumber = Convert.ToInt32(Request.Form["CountryNumber"]);
                        _DB.Country.Add(new Country() { CountryName = Request.Form["CountryName"], CountryNumber = CountryNumber });
                        _DB.SaveChanges();
                    }
                    break;
                case "Edit":
                    if (Request.Form["CountryNumber"] != "" && Request.Form["CountryNumber"] != null)
                    {
                        int CountryCC = Convert.ToInt32(Request.Form["CountryCode"]);
                        var x = _DB.Country.Single(r => r.CountryCode == CountryCC);
                        x.CountryName = Request.Form["CountryName"];
                        x.CountryNumber = Convert.ToInt32(Request.Form["CountryNumber"]);
                        _DB.SaveChanges();
                    }
                    break;
                case "Delete":
                    if (Request.Form["CountryCode"] != "" && Request.Form["CountryCode"] != null)
                    {
                        int CountryCode = Convert.ToInt32(Request.Form["CountryCode"]);
                        _DB.Country.Remove(_DB.Country.Single(r => r.CountryCode == CountryCode));
                        _DB.SaveChanges();
                    }
                    break;
            }

            var DBList = from c in _DB.Country select c;

            if (!string.IsNullOrEmpty(sortname) && !string.IsNullOrEmpty(sortorder))
            {
                DBList = DBList.OrderBy(sortname, (sortorder == "asc"));
            }

            if (!string.IsNullOrEmpty(qtype) && !string.IsNullOrEmpty(query))
            {
                DBList = DBList.Like(qtype, query);
            }

            DBList = DBList.Skip((page - 1) * rp).Take(rp);


            var flexgrid = new
            {
                page = page,
                total = _DB.Country.Count(),
                rows = DBList
                .Select(x => new
                {
                    id = x.CountryName,
                    cell = new { x.CountryCode, x.CountryNumber, x.CountryName }
                }
                )

            };


            return Json(flexgrid, JsonRequestBehavior.AllowGet);
        }

        #endregion Country


        #region AutoComplete

        public ActionResult AutoComplete()
        {

            return View();
        }
        public ActionResult AutoCompleteCountry(string term)
        {
            var result = _DB.Country
                        .Where(r => r.CountryName.Contains(term))
                        .Take(10)
                        .Select(r => new { label = r.CountryName });
            return Json(result, JsonRequestBehavior.AllowGet);
        }
        #endregion
    }
}
