﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using AutoComplete1.Models;

namespace AutoComplete1.Controllers
{
    public class ProductController : Controller
    {
        [HttpGet]
        public ActionResult Search()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Search(Product product)
        {
            return RedirectToAction("Details", "Product", new { Id = product.Id });
        }

        public ActionResult Details(int Id)
        {
            using (var db = new MyContext())
            {
                return View(db.Products.FirstOrDefault(p => p.Id == Id));
            }
        }
    }
}
