﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using AutoComplete1.Models;

namespace AutoComplete1.Controllers
{
    public class ProductApiController : ApiController
    {
        [HttpGet]
        public IEnumerable<Product> GetProducts(string query = "")
        {
            using (var db = new MyContext())
            {
                return String.IsNullOrEmpty(query) ? db.Products.ToList() :
                db.Products.Where(p => p.Description.Contains(query)).ToList();
            }
        }
    }
}
