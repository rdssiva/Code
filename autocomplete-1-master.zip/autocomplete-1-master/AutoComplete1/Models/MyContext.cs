﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.Entity;


namespace AutoComplete1.Models
{
    public class MyContext : DbContext
    {
        public DbSet<Product> Products { get; set; }
    }
}