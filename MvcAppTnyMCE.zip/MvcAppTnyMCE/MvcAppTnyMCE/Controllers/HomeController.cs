﻿using System.Web.Mvc;
using MvcAppTnyMCE.Models;

namespace MvcAppTnyMCE.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Index(SampleModel model)
        {
            model.RichText1FullHtml = model.RichText1;
            model.RichText2FullHtml = model.RichText2;

            model.RichText1 = null;
            model.RichText2 = null;
            return View(model);
        }

    }
}
