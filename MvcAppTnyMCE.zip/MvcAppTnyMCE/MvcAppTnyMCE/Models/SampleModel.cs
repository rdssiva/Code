﻿using System;
using System.ComponentModel.DataAnnotations;
using System.Web.Mvc;

namespace MvcAppTnyMCE.Models
{
    public class SampleModel
    {
        [AllowHtml]
        [Display(Name = "Ritch Text 1")]
        public String RichText1 {get; set;}

        [AllowHtml]
        public String RichText1FullHtml { get; set; }

        [AllowHtml]
        [Display(Name = "Ritch Text 2")]
        public String RichText2 {get; set;}

        [AllowHtml]
        public String RichText2FullHtml { get; set; }
    }
}